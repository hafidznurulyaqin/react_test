create definer = root@localhost trigger must_an_adult
    before INSERT
    on users
    for each row
begin
		if NEW.age < 18
        then
			signal sqlstate '45000'
				set message_text = 'Must be an adult';
		end if;
    end;

